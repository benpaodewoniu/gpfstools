"""
把这个脚本放在一个新的目录下面
假设你目录为

    D:/gps

在下面的参数中

    all_dir = "D:/gps/"

然后在这个目录下面要有

    gps.xlsx
    gpfs.exe

这个 gps.xlsx 第一列是地址
在 cmd 中运行这个脚本，遇到 "请按任意键继续" 就 「回车」

"""
import os
import shutil
import xlrd
import time

all_dir = "新目录的绝对路径"
file_name = "./gps.xlsx"
gps_software = "./gpfs.exe"


def init_address():
    data = []
    xls = xlrd.open_workbook(file_name)
    for i in range(len(xls.sheets()[0].col_values(0))):
        data.append(xls.sheets()[0].col_values(0)[i])
    return data


def win10():
    api_port = 6000
    gatesway_port = 9090

    data = init_address()
    for i in range(len(data)):
        print("地址" + str(i) + data[i] + " 开始生成")
        os.mkdir(all_dir + str(i))
        shutil.copy(gps_software, all_dir + str(i))
        with(open(all_dir + str(i) + "/run.bat", "w+")) as f:
            f.write("set IPFS_PATH=" + all_dir + str(i) + "data\n")
            f.write("gpfs.exe daemon  --init --miner-address=" + data[i] + "\n")
            f.write("pause")
        os.system(all_dir + str(i) + "run.bat")

        file_data = ''
        with(open(all_dir + str(i) + '/data/config', 'r')) as f:
            lines = f.readlines()
            for line in lines:
                if line.find('    "API": "/ip4/127.0.0.1/tcp/5001",') == 0:
                    line = '    "API": "/ip4/127.0.0.1/tcp/' + str(api_port) + '",\n'
                elif line.find('    "Gateway": "/ip4/127.0.0.1/tcp/8080"') == 0:
                    line = '    "Gateway": "/ip4/127.0.0.1/tcp/' + str(gatesway_port) + '"\n'
                file_data += line
        with(open(all_dir + str(i) + '/data/config', 'w')) as f:
            f.writelines(file_data)
        print("地址" + str(i) + data[i] + " 生成结束")
        api_port += 1
        gatesway_port += 1


if __name__ == '__main__':
    win10()

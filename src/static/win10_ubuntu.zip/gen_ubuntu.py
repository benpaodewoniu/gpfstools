import os
import shutil
import time

all_dir = "绝对路径"
gps_software = "./gpfs"

data = ["", ""]


def ubuntu():
    api_port = 6000
    gatesway_port = 9090

    for i in range(len(data)):
        print("地址" + str(i) + data[i] + " 开始生成")
        os.mkdir(all_dir + str(i))
        shutil.copy(gps_software, all_dir + str(i))
        with(open(all_dir + str(i) + "/run.sh", "w+")) as f:
            f.write("export IPFS_PATH=" + all_dir + str(i) + "/data\n")
            f.write("nohup ./gpfs daemon --init --miner-address=" + data[i] + " &")
        os.system("sh " + all_dir + str(i) + "/run.sh")
        time.sleep(5)
        file_data = ''
        with(open(all_dir + str(i) + '/data/config', 'r')) as f:
            lines = f.readlines()
            for line in lines:
                if line.find('    "API": "/ip4/127.0.0.1/tcp/5001",') == 0:
                    line = '    "API": "/ip4/127.0.0.1/tcp/' + str(api_port) + '",\n'
                elif line.find('    "Gateway": "/ip4/127.0.0.1/tcp/8080"') == 0:
                    line = '    "Gateway": "/ip4/127.0.0.1/tcp/' + str(gatesway_port) + '"\n'
                file_data += line
        with(open(all_dir + str(i) + '/data/config', 'w')) as f:
            f.writelines(file_data)
        print("地址" + str(i) + data[i] + " 生成结束")
        api_port += 1
        gatesway_port += 1


if __name__ == '__main__':
    ubuntu()
